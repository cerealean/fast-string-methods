export { startsWith } from './startsWith/startsWith.mjs';
